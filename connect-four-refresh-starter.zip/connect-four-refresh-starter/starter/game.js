const ConnectFour = require("./class/connect-four");

connectFour = new ConnectFour();
