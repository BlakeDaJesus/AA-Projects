callOnTarget = (func, obj1, obj2) => func.call(obj1, obj2);

/*****************************************************************************/
/***************** DO NOT MODIFY ANYTHING UNDER THIS LINE ********************/

module.exports = callOnTarget;
