const allTheArgs = (func, ...args) => func.bind(args, ...args);


/*****************************************************************************/
/***************** DO NOT MODIFY ANYTHING UNDER THIS LINE ********************/

module.exports = allTheArgs;
