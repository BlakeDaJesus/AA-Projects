# Practice: Review of Arrow functions

In this practice, you will review the difference between a regular function and
an arrow function.

## Set up

Clone the starter from the **Download** link at the bottom of this page.

## Instructions

Convert all the functions in the __review.js__ file into arrow functions.